#!/bin/sh
timeout --foreground 300 ./qemu-system-x86_64 \
    -L ./pc-bios \
    -m 128M \
    -append "console=ttyS0" \
    -kernel bzImage \
    -initrd rootfs.cpio \
    -device vn \
    -nographic \
    -no-reboot \
    -monitor /dev/null
